﻿using AppMinhasCompras.Model;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AppMinhasCompras.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditarProduto : ContentPage
    {
        public EditarProduto()
        {
            InitializeComponent();
        }
        private async void ToolbarItem_Clicked_Salvar(object sender, EventArgs e)
        {
            try
            {
                /**
                 * Obtém qual foi o Produto anexado no BindingContext da página no momento que
                 * ela foi criada e enviada para navegação.
                 */
                Produto produtoAnexado = BindingContext as Produto;
                /**
                 * Preenchendo a model de acordo com os valores dos Entry. Note que recuperamos a Id
                 * do BindingContext, como feito acima.
                 */
                Produto p = new Produto
                {
                    //Id = ((Produto) BindingContext).Id,
                    ProID = produtoAnexado.ProID,
                    ProDescricao = txtDescricao.Text,
                    ProQuantidade = Convert.ToDouble(txtQuantidade.Text),
                    ProPreco = Convert.ToDouble(txtPreco.Text),
                };
                /**
                 * Método para atualizar o registro no arquivo db3. Note que o método recebe um model
                 * preenchido e neste deve conter o Id para que seja feito o Where do Update.
                 */
                await App.Database.Update(p);

                await DisplayAlert("Produto Alterado", " com Sucesso !!!!", "OK");

                await Navigation.PushAsync(new Listagem());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Atenção", ex.Message, "OK");
            }
        }
    }
}
