﻿/**
 * A biblioteca SQLite é chamada aqui para que as anotações de chave primária
 * e de autoIncremento possam ser usadas na propriedade proID
 */
using SQLite;

namespace AppMinhasCompras.Model
{

    /**
     * A classe model Produto define como os dados serão armazenados no SQLite (arquivo db3)
     * e como serão transportados entre a View e o SQLite.
     */
    public class Produto
    {
        [PrimaryKey, AutoIncrement]
        public int ProID { get; set; }
        public string ProDescricao { get; set; }
        public double ProQuantidade { get; set; }
        public double ProPreco { get; set; }
    }
}

