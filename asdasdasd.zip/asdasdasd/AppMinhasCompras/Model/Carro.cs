﻿/**
 * A biblioteca SQLite é chamada aqui para que as anotações de chave primária
 * e de autoIncremento possam ser usadas na propriedade proID
 */
using SQLite;

namespace AppMinhasCompras.Model
{

    public class Carro
    {
        [PrimaryKey, AutoIncrement]
        public int carID { get; set; }
        public string carNome { get; set; }
        public string carPlaca { get; set; }
    }
}

