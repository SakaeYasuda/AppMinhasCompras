﻿using AppMinhasCompras.Model;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AppMinhasCompras.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditarCarro : ContentPage
    {
        public EditarCarro()
        {
            InitializeComponent();
        }

        private async void ToolbarItem_Clicked_Salvar(object sender, EventArgs e)
        {
            try
            {
                // Obtém o carro anexado no BindingContext da página
                Carro carroAnexado = BindingContext as Carro;

                // Preenche a model de acordo com os valores dos Entry
                Carro carroAtualizado = new Carro
                {
                    carID = carroAnexado.carID,
                    carNome = txtNome.Text,
                    carPlaca = txtPlaca.Text
                };

                // Atualiza o registro no banco de dados
                await App.Database.Update(carroAtualizado);

                await DisplayAlert("Carro Alterado", "Alterado com sucesso!", "OK");

                // Navega de volta para a página de listagem após a atualização
                await Navigation.PushAsync(new ListagemCarros());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Atenção", ex.Message, "OK");
            }
        }
    }
}
